from sigma.processing.transformations.placeholder import ValueListPlaceholderTransformation
from sigma.processing.pipeline import ProcessingItem, ProcessingPipeline


def SecurityOnion_playbook_placeholders() -> ProcessingPipeline:
    """Resolve ``Field|expand: '%name%'`` placeholders in playbook question queries.

    Security Onion supplies per-event values as ``vars:`` in a second pipeline;
    ProcessingPipeline.__add__ merges them in and ValueListPlaceholderTransformation
    resolves each placeholder, raising on any missing var.
    """
    return ProcessingPipeline(
        name="SecurityOnion playbook placeholder expansion",
        priority=80,
        allowed_backends=frozenset({"security_onion"}),
        items=[
            ProcessingItem(
                identifier="SecurityOnion_playbook_value_placeholders",
                transformation=ValueListPlaceholderTransformation(),
            ),
        ],
    )
