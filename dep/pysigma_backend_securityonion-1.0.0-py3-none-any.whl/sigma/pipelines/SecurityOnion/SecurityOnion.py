from sigma.pipelines.common import logsource_windows, windows_logsource_mapping
from sigma.pipelines.base import Pipeline
from sigma.processing.transformations import AddConditionTransformation, FieldMappingTransformation
from sigma.processing.transformations.placeholder import ValueListPlaceholderTransformation
from sigma.processing.pipeline import ProcessingItem, ProcessingPipeline

# TODO: the following code is just an example extend/adapt as required.
# See https://sigmahq-pysigma.readthedocs.io/en/latest/Processing_Pipelines.html for further documentation.

@Pipeline
def SecurityOnion_pipeline() -> ProcessingPipeline:        # Processing pipelines should be defined as functions that return a ProcessingPipeline object.
    return ProcessingPipeline(
        name="OQL example pipeline",
        allowed_backends=frozenset(),                                               # Set of identifiers of backends (from the backends mapping) that are allowed to use this processing pipeline. This can be used by frontends like Sigma CLI to warn the user about inappropriate usage.
        priority=20,            # The priority defines the order pipelines are applied. See documentation for common values.
        items=[
            ProcessingItem(     # This is an example for processing items generated from the mapping above.
                identifier=f"SecurityOnion_windows_{service}",
                transformation=AddConditionTransformation({ "source": source}),
                rule_conditions=[logsource_windows(service)],
            )
            for service, source in windows_logsource_mapping.items()
        ] + [
            ProcessingItem(     # Field mappings
                identifier="SecurityOnion_field_mapping",
                transformation=FieldMappingTransformation({
                    "EventID": "event_id",      # TODO: define your own field mappings
                })
            )
        ],
    )


# NOTE: intentionally NOT decorated with @Pipeline. pySigma's @Pipeline uses a
# process-wide singleton (sigma/pipelines/base.py), so decorating a second
# function in this module would collapse both onto one instance. Plugin
# autodiscovery picks up plain functions via inspect.isfunction, so a bare
# function registers correctly as its own pipeline identifier.
def SecurityOnion_playbook_placeholders() -> ProcessingPipeline:
    """Resolve %name% placeholders in playbook question queries from pipeline.vars.

    Playbook question queries ship as real Sigma rules that use the standard
    ``Field|expand: '%name%'`` placeholder syntax. At hydration time, Security
    Onion supplies the per-event values as ``vars:`` in a second pipeline passed
    to ``sigma convert`` via an in-memory pipe (e.g. ``-p /dev/fd/3``). pySigma's
    ProcessingPipeline.__add__ merges the vars dict into this pipeline, and the
    ValueListPlaceholderTransformation below resolves each placeholder against it.

    Priority 80 runs this before the SO baseline pipeline (priority 90) performs
    its field renames, so placeholders are resolved on the original field names.
    An unresolved placeholder raises, surfacing a missing var rather than emitting
    a silently-wrong query.
    """
    return ProcessingPipeline(
        name="SecurityOnion playbook placeholder expansion",
        priority=80,
        allowed_backends=frozenset({"security_onion"}),
        items=[
            ProcessingItem(
                identifier="SecurityOnion_playbook_value_placeholders",
                transformation=ValueListPlaceholderTransformation(),
            ),
        ],
    )